//
// useIntList.cpp
//
// use the linked list hierarchy in (not a good idea)

#include "IntList.h"
int main()
{
  IntList ilist;
  ilist.add(3);
  ilist.add(5);
  ilist.add(7);
  ilist.print();
}
