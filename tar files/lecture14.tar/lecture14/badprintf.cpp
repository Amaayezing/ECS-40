//
// badprintf.cpp
//

#include<cstdio>
int main()
{
  double x = 3.14;
  printf("%d\n",x);
}
