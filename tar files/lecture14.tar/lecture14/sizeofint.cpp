#include<iostream>
using namespace std;
int main()
{
  cout << sizeof(int) << endl;
}
