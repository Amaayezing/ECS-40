//
// numeric1.cpp
//
#include <iostream>
using namespace std;

int main() 
{
  double a = 1.23456789;
  double b = 5432.0;
  double c = 1.0e-18;

  cout << "default:" << endl;
  cout << a << endl;
  cout << b << endl;
  cout << c << endl;
}
