#include <stdio.h>
int main()
{
  double x = 1.23456789;

  printf("% 12.5f\n",x);
  printf("%-12.5f\n",x);
}
