//
// badprintf.c
//

#include<stdio.h>
int main()
{
  double x = 3.14;
  printf("%d\n",x);
  return 0;
}
