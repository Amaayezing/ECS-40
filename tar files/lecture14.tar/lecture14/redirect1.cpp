//
// redirect1.cpp
//
#include<iostream>
using namespace std;
int main()
{
  int i;
  cin >> i;
  cout << " i=" << i << " written using cout" << endl;
  cerr << " written using cerr" << endl;
  clog << " written using clog" << endl;
}
