//
// randmax.cpp
//

#include<iostream>
#include<cstdlib> // rand()
using namespace std;

int main()
{
  cout << RAND_MAX << endl;
}
