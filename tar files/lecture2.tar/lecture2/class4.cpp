//
// class4.cpp
//
// Demonstrate the use of a class
// The class Value interface is defined in Value2.h 
// The class Value implementation is defined in Value2.cpp

#include "Value2.h"
int main()
{
  Value v;

  v.set(3);
  v.print();
}
