//
// Value2.cpp
//
// Definition of the Value class

#include "Value2.h"
#include<iostream>
using namespace std;

void Value::print(void)
{
  cout << i << endl;
}

void Value::set(int x)
{
  i = x;
}
