//
// for.c
//
int main()
{
  double a[5];
  for ( int i = 0; i < 5; i++ )
  {
    a[i] = 0;
  }

  i = 0;
}
