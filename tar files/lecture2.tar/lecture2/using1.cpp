//
// using1.cpp
//
#include<iostream>
using namespace std;

int main()
{
  int clog;
  clog = 2;
  cout << clog << endl;
}
