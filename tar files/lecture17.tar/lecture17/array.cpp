//
// array.cpp
//
// use the C++11 array container

#include<iostream>
#include<array>
using namespace std;

int main()
{
  array<int,4> a1 { 1, 2, 3, 4 };
}
