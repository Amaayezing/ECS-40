//
// add.cpp: add two integers
//
#include<iostream>

int main()
{
  int a, b;
  std::cout << "Enter two integers: ";
  std::cin >> a >> b;
  std::cout << "a = " << a << std::endl;
  std::cout << "b = " << b << std::endl;
  std::cout << "the sum is " << a+b << std::endl;
}
