int main()
{
  int* a = new int[10];
}
