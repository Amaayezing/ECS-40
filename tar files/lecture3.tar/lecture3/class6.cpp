//
// class6.cpp
//
// Demonstrate the use of a class

#include "Value4.h"
int main()
{
  Value v;

  v.set(3);
  v.print();
}
