//
// useB.cpp
//

#include "B.h"

int main()
{
  B b;
}
