#ifndef B_H
#define B_H

#include "A.h"

class B : public A
{
  public:
    int b_pub;
};
#endif
