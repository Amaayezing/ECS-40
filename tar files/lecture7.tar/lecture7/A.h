#ifndef A_H
#define A_H

class A
{
  public:
    int a_pub;
};
#endif
